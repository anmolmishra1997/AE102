from matplotlib import pyplot as plt
x = [0.0, 0.11, 0.12, 0.13, 0.14]
y = [0.69,0.9,0.74,0.76,0.8]
plt.plot(x,y,'ro')
plt.plot(x,y,'r-')
plt.xlabel("t")
plt.ylabel("L")
plt.title("Assignment 1")
plt.annotate("outlier", xy= (0.11,0.9))
plt.savefig("plot.png")