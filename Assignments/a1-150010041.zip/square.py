for var in range(1,11):
    print (var*var)
var = 1
while var!=11:
    print (var*var)
    var+=1